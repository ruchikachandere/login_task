import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LoginScreen extends StatefulWidget{
  @override
  _LoginScreenState createState() => _LoginScreenState();
    
  }
  
  class _LoginScreenState extends State<LoginScreen> {
  double height, width;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false;
  String _firstname;
  String _lastname;
  String _emailid;
  String _phoneno;
  String _address;
  final fnameController = TextEditingController();
  var maxLength;
 

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return Scaffold( 
      //resizeToAvoidBottomInset: false,
     backgroundColor: Colors.grey,
      body: ListView(
        children: <Widget>[
          SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(
                 alignment: Alignment.center,
                 padding: EdgeInsets.only(top:10),
                    child: Text("Sign in", style: TextStyle(
                       fontSize: 35, fontWeight: FontWeight.bold, color: Colors.black
                         ),
                     ),
                ),
                Container(
                  padding: EdgeInsets.all(16),
                  child:Card(
                    color: Colors.grey[300],
                    shape: RoundedRectangleBorder(
                     // borderRadius: BorderRadius.circular(10.0),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(50),
                     bottomRight: Radius.circular(50),
                     //topRight: Radius.circular(30)
                     ),
                    ),
                    child: Padding(
                        padding: EdgeInsets.only(top: 8.0),
                           child: Form(
                              key: _formKey,
                              autovalidate: _autoValidate,
                                  child: Column(
                                   children: <Widget>[
                                     this.firstNameTextField(),
                                     this.lastNameTextField(),
                                     this.emailIDField(),
                                     this.phoneNoField(),
                                     this.addressFeild(),
                                     this.submitButton(context),
                                   ],
                                  )
                         )
                    )
                  //)
                 )
                )
              ],
            )

         )
        ],
      )
    );
    
  }

 Widget firstNameTextField() {
   return Container(
     padding: EdgeInsets.all(16),
      child: TextFormField(
                    controller: fnameController,
                     decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter First Name',
                      counterText: "",
                    ),
                    maxLength: 30,
                     keyboardType: TextInputType.text,
                     validator: (String arg) {
                        if(arg.length == 0)
                        return 'Fisrt Name should not be blank';
                        else if(arg.length>30)
                        return 'First Name not be exceed than 30 charactor';
                        else if (arg.length < 2)
                        return 'First Name must be more than 2 charater';
                     },
                      onSaved: (String val) {
                      _firstname = val;
                     },
      ),        
   );
 }

 Widget lastNameTextField(){
   return Container(
     padding: EdgeInsets.all(16),
      child: TextFormField(
                   // controller: nameController
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter Last Name',
                      counterText: "",
                    ),
                    maxLength: 30,
                    keyboardType: TextInputType.text,
                    validator: (String arg) {
                        if(arg.length == 0)
                        return 'Last Name should not be blank';
                        else if(arg.length < 2)
                        return 'Last Name must be more than 2 charater';
                        else if(arg.length>30)
                        return 'Last Name not be exceed than 30 charactor';
                     },
                      onSaved: (String val) {
                      _lastname = val;
                     },
                  ),
   );
 }

 Widget emailIDField(){
   return Container(
     padding: EdgeInsets.all(16),
      child: TextFormField(
                   // controller: nameController,
                   maxLength: 50,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter Email Id',
                      counterText: "",
                    ),
                    keyboardType: TextInputType.emailAddress,
                    validator: (String arg) {
                        if(arg.length == 0)
                        return 'Email Id should not be blank';
                        else if(arg.length < 8)
                        return 'Email Id must be more than 8 charater';
                        else if(arg.length>30)
                        return 'Email Id not be exceed than 50 charactor';
                        
                     },
                      onSaved: (String val) {
                      _emailid = val;
                     },
                  ),
   );
 } 

  Widget phoneNoField(){
   return Container(
     padding: EdgeInsets.all(16),
      child: TextFormField(
                   // controller: nameController,
                  maxLength: 10,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter Phone No',
                      counterText: "",
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (String arg) {
                        // if(arg.length < 8)
                        // return 'Phone no must be more than 8 charater';
                         if(arg.length>10)
                        return 'Phone no not be exceed than 10 charactor';
                        else if(arg.length == 0)
                        return 'Phone no should not be blank';
                     },
                      onSaved: (String val) {
                      _phoneno = val;
                     },
                  ),
   );
 }
 
 Widget addressFeild(){
    return Container(
     padding: EdgeInsets.all(16),
      child: TextFormField(
                   // controller: nameController,
                    maxLength: 50,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter Address',
                      counterText: "",
                    ),
                    keyboardType: TextInputType.text,
                    validator: (String arg) {
                      if(arg.length == 0)
                        return 'Fisrt Name should not be blank';
                         else if(arg.length < 8)
                        return 'First Name must be more than 8 charater';
                        else if(arg.length>50)
                        return 'First Name not be exceed than 50 charactor';
                     },
                      onSaved: (String val) {
                      _address = val;
                     },
                  ),
   );
 }
 
 Widget submitButton(BuildContext context){
   return Container(
     padding: EdgeInsets.all(16),
     width: MediaQuery.of(context).size.width,
     height: 80,
      child: RaisedButton(
               shape: new RoundedRectangleBorder(
                 borderRadius: new BorderRadius.circular(10.0)),
                  child: Text("Submit",
                       textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize:20)), 
                          onPressed: () {
                          if (_formKey.currentState.validate()) {
                            _formKey.currentState.save();
                          }
                          else
                          setState(() {
                           _autoValidate = true;
                           });
                          },
                          color: Colors.red,
      )
   );
 }
}
