class LoginData {
  final String fname;
  final String lname;
  final String email;
  final int phone;
  final String address;

  LoginData({this.fname, this.lname, this.email, this.phone, this.address});
  Map<String, dynamic> toMap() {
    return {
       'fname' : fname,
       'lname' : lname,
       'email' : email,
       'phone' : phone,
       'address' : address
    };
  }

  final fido = LoginData(
   fname: 'puja',
   lname:  'dhakulkar',
   email: 'puja@gmail.com',
   phone: 6789876,
   address: 'jegrfegjlkrgj'
);


}


// class Person {
//   int id;
//   String name;
//   String city;

//   Person({this.id, this.name, this.city});

//   Map<String, dynamic> toMap() => {
//       "id": id,
//       "name": name,
//       "city": city,
//     };

//     factory Person.fromMap(Map<String, dynamic> json) => new Person(
//       id: json["id"],
//       name: json["name"],
//       city: json["city"],
//     );
// }