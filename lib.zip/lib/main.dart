import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:loginscreen/loginscreen.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import 'logindata.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }

void main()async {
  final Future<Database> database = openDatabase(
    join (await getDatabasesPath(), 'login_database.db'),
    onCreate: (db, version){
      return db.execute(
        "CREATE TABLE loginData(fname STRING PRIMARY KEY, lname TEXT, email TEXT, phone INTEGER, address TEXT)",
      );
    },
    version: 1,
  );

Future<void> insertLoginData(LoginData loginData) async {
  // Get a reference to the database.
  final Database db = await database;
  // Insert the Dog into the correct table. You might also specify the
  // `conflictAlgorithm` to use in case the same dog is inserted twice.
  // In this case, replace any previous data.
  await db.insert(
    'loginData',
    loginData.toMap(),
    conflictAlgorithm: ConflictAlgorithm.replace,
  );
}

Future<List<LoginData>> login() async {
  // Get a reference to the database.
  final Database db = await database;
  // Query the table for all The Dogs.
  final List<Map<String, dynamic>> maps = await db.query('loginData');

  // Convert the List<Map<String, dynamic> into a List<Dog>.
  return List.generate(maps.length, (i) {
    return LoginData(
       fname : maps[i]['fname'],
       lname : maps[i]['lname'],
       email : maps[i]['email'],
       phone : maps[i]['phone'],
       address: maps[i]['address'],
      
    );
  });
}
// Now, use the method above to retrieve all the dogs.
print(await login()); 

}

}







